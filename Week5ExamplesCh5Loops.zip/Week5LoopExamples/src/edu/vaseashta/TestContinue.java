package edu.vaseashta;

public class TestContinue {

	public static void main(String[] args) {
		int sum = 0;
		int number = 0;
		
		while (number < 20) 
		{
			number++;
			System.out.println("The number is " + number + ".");
			if (number == 10 || number == 11)
				continue; //When active, when number = 10 or number = 11, this skips past executing the next statement which is sum += number and once number11 hits 12, it executes sum again.
			System.out.println("The sum is " + sum + ".");
			sum += number;
			System.out.println("The sum is " + sum + ".");
		}
		
		System.out.println("The sum is " + sum);

	}

}
