package edu.vaseashta;

import java.util.Scanner;

public class TestBreak
{

	public static void main(String[] args) 
	{
		Scanner input = new Scanner(System.in);

		//Listing 5.9 on Page 184. Shows how to use an If statement to break a loop.
		
		int sum = 0;
		int number = 0;
		
		while (number < 20) 
		{
			number++; //Means same thing as number = number + 1
			sum += number; //Means same thing as sum = sum + number
			System.out.println("The number is " + number); 
			System.out.println("The sum is " + sum);
			if (sum >= 100)
				break; //When active, this breaks the loop above when sum >=100
		}
	}
}